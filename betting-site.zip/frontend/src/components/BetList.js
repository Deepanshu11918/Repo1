// React bet list component placeholder
