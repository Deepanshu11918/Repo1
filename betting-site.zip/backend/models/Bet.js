
const mongoose = require('mongoose');

const BetSchema = new mongoose.Schema({
  user: String,
  match: String,
  amount: Number,
  prediction: String,
  result: String,
  status: { type: String, default: 'pending' }
});

module.exports = mongoose.model('Bet', BetSchema);
